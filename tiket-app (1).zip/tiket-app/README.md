# Tikèt — Caisse & commandes (app mobile native)

Application de caisse (POS) pour restauration + boutique, avec impression Bluetooth
sur imprimante thermique classique (protocole SPP / ESC-POS).

## ⚠️ Important à savoir avant de commencer

Cette app utilise un module natif Bluetooth (`react-native-bluetooth-escpos-printer`).
Cela veut dire :
- **Ça ne marche PAS avec Expo Go** (l'app de test rapide). Il faut un vrai projet
  React Native "bare", compilé toi-même, ou Expo avec `expo-dev-client` + `prebuild`.
- **Ça ne marche PAS dans un émulateur** — les émulateurs Android n'ont pas de vraie
  puce Bluetooth. Il faut tester sur un **téléphone Android physique** relié en USB.
- Le Bluetooth "classique" (SPP) que ciblent la plupart des imprimantes thermiques
  bon marché n'est **pas disponible sur iPhone** (Apple ne l'autorise pas pour les
  apps grand public). Cette app est donc pensée **Android en priorité**.

## Ce qui est déjà fait

- `App.js` — navigation par onglets (Commande / En cours / Historique / Rapports / Stock / Catalogue), bandeau d'essai gratuit
- `src/context/AppContext.js` — état partagé : commandes, ventes, stock, fournisseurs, essai gratuit, sauvegarde locale
- `src/services/storage.js` — persistance avec AsyncStorage (les données restent sur le téléphone)
- `src/services/bluetoothPrinter.js` — recherche, connexion et impression Bluetooth (reçu + ticket cuisine, avec numéro de commande)
- `src/screens/CaisseScreen.js` — constitution du panier et envoi de la commande (le client consomme avant de payer)
- `src/screens/CommandeScreen.js` — liste des commandes en cours, réimpression du ticket cuisine, encaissement
- `src/screens/HistoriqueScreen.js` — ventes encaissées, réimpression
- `src/screens/RapportsScreen.js` — chiffre d'affaires 30 jours (journalier) et 12 mois (mensuel)
- `src/screens/StockScreen.js` — inventaire, mouvements de stock, fournisseurs (mode Boutique)
- `src/screens/CatalogueScreen.js` — gestion des produits, imprimante, statut d'abonnement
- `src/data/seedProducts.js` — quelques produits de démonstration à remplacer par les tiens
- `assets/icon.png` / `assets/icon.svg` — l'icône de l'application, prête à intégrer

### Modèle d'essai gratuit
7 jours d'accès complet à partir de la première ouverture de l'app. Passé ce délai, l'app passe
en mode lecture seule : l'historique, les rapports et le catalogue restent consultables, mais
toute création, vente, encaissement, impression ou mouvement de stock est bloqué avec un message
explicite. Un contrôle "Aperçu du mode verrouillé" dans l'onglet Catalogue permet de tester ce
comportement sans attendre 7 jours.

## Le flux commande / paiement

1. **Nouvelle commande** : le vendeur sélectionne les articles, touche "Envoyer la commande" — aucun paiement n'est demandé à cette étape. La commande reçoit un numéro unique (#0001, #0002...) et peut être imprimée pour la cuisine.
2. **En cours** : toutes les commandes envoyées mais pas encore payées apparaissent ici, avec le total, le détail, et un bouton pour réimprimer le ticket cuisine si besoin.
3. **Encaissement** : quand le client a fini de consommer, le vendeur touche "Encaisser" sur la commande, choisit le mode de paiement, et valide. La commande disparaît alors de "En cours" et un reçu de paiement est proposé à l'impression.
4. **Historique** : toutes les ventes encaissées, consultables et réimprimables, avec leur numéro de commande d'origine.

## Intégrer l'icône de l'application

Le fichier `assets/icon.png` (1024×1024) contient l'icône déjà conçue pour Tikèt.
Une fois le vrai projet Android créé (voir étape 2 ci-dessous) :

1. Ouvre le projet dans Android Studio
2. Clic droit sur `android/app/src/main/res` → **New → Image Asset**
3. Choisis "Launcher Icons (Adaptive and Legacy)", puis sélectionne `assets/icon.png` comme image source
4. Android Studio génère automatiquement toutes les tailles nécessaires (mdpi à xxxhdpi)

Tu peux aussi demander directement à Claude Code de le faire pour toi une fois le projet créé.

## Étapes pour compiler le projet

### 1. Prérequis à installer sur ton ordinateur
- [Node.js](https://nodejs.org) version 18 ou plus
- Java JDK 17
- [Android Studio](https://developer.android.com/studio) (pour le SDK Android et les outils de build)
- Un téléphone Android avec le **mode développeur** et le **débogage USB** activés

### 2. Créer le projet React Native de base
Les fichiers fournis ici (App.js, src/, package.json...) doivent être placés dans un
vrai projet React Native généré par l'outil officiel, car celui-ci crée aussi les
dossiers natifs `android/` et `ios/` qui ne peuvent pas être livrés sous forme de
simple texte.

```bash
npx @react-native-community/cli init TiketApp --version 0.74.1
cd TiketApp
```

Puis remplace le `App.js`, `index.js`, `app.json`, `package.json`, `babel.config.js`
générés par ceux fournis ici, et copie le dossier `src/` entier dedans.

### 3. Installer les dépendances

```bash
npm install
npm install react-native-bluetooth-escpos-printer @react-native-async-storage/async-storage react-native-safe-area-context
```

### 4. Ajouter les permissions Bluetooth (Android)

Ouvre `android/app/src/main/AndroidManifest.xml` et ajoute, juste avant `<application>` :

```xml
<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

(Ces permissions sont nécessaires car Android considère la recherche Bluetooth
comme une fonction sensible à la vie privée depuis la version 12.)

### 5. Lancer l'app sur ton téléphone

Branche ton téléphone Android en USB, puis :

```bash
npx react-native run-android
```

La première compilation peut prendre plusieurs minutes.

### 6. Utiliser Claude Code pour la suite

Une fois Node et Android Studio installés, tu peux ouvrir ce dossier avec
**Claude Code** et lui demander de corriger les éventuelles erreurs de compilation,
d'ajouter des fonctionnalités, ou de préparer la publication sur le Play Store —
c'est beaucoup plus efficace pour ce genre d'itération que de tout faire à la main.

## Test de l'impression Bluetooth

1. Allume ton imprimante thermique et mets-la en mode appairage
2. Dans l'app, va dans l'onglet **Catalogue** → **Connecter une imprimante**
3. Choisis-la dans la liste (appairée ou détectée à proximité)
4. Fais une vente dans l'onglet **Caisse**, puis touche **Imprimer reçu**

Si l'impression échoue : vérifie que ton imprimante est bien de type **Bluetooth
classique (SPP)** et pas uniquement BLE — la plupart des modèles génériques à
55-80mm vendus en Côte d'Ivoire le sont, mais ça vaut le coup de vérifier la fiche
technique avant d'acheter.

## Prochaines pistes

- Remplacer les produits de démonstration par ton vrai catalogue
- Ajouter un logo dans l'en-tête
- Génération de rapports de vente exportables (PDF/Excel)
- Multi-utilisateurs si tu veux gérer plusieurs vendeurs sur le même compte
