import React, { useState } from "react";
import { SafeAreaView, View, Text, TouchableOpacity, StyleSheet, StatusBar, ScrollView } from "react-native";
import { AppProvider, useApp } from "./src/context/AppContext";
import CaisseScreen from "./src/screens/CaisseScreen";
import CommandeScreen from "./src/screens/CommandeScreen";
import HistoriqueScreen from "./src/screens/HistoriqueScreen";
import RapportsScreen from "./src/screens/RapportsScreen";
import StockScreen from "./src/screens/StockScreen";
import CatalogueScreen from "./src/screens/CatalogueScreen";
import { colors } from "./src/theme";

function AppShell() {
  const [tab, setTab] = useState("caisse");
  const { openOrders, products, daysRemaining, isLocked, lockMessage } = useApp();

  const lowStockCount = products.filter(
    (p) => p.cat === "boutique" && p.stock !== undefined && p.stock <= (p.lowStock ?? 5)
  ).length;

  const TABS = [
    { key: "caisse", label: "Commande", icon: "🧾" },
    { key: "encours", label: "En cours", icon: "⏳", badge: openOrders.length },
    { key: "historique", label: "Historique", icon: "📖" },
    { key: "rapports", label: "Rapports", icon: "📊" },
    { key: "stock", label: "Stock", icon: "📦", badge: lowStockCount },
    { key: "catalogue", label: "Catalogue", icon: "🗂️" },
  ];

  return (
    <SafeAreaView style={styles.root}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>TIKÈT</Text>
        <Text style={styles.headerSubtitle}>caisse & commandes</Text>
      </View>

      {isLocked ? (
        <View style={styles.lockedBanner}>
          <Text style={styles.lockedText}>
            🔒 Essai terminé — l'historique reste consultable, la vente et l'impression sont désactivées.
          </Text>
        </View>
      ) : (
        <View style={styles.trialBanner}>
          <Text style={styles.trialText}>
            Essai gratuit — {daysRemaining} jour{daysRemaining > 1 ? "s" : ""} restant{daysRemaining > 1 ? "s" : ""}
          </Text>
        </View>
      )}

      {lockMessage && (
        <View style={styles.toast}>
          <Text style={styles.toastText}>{lockMessage}</Text>
        </View>
      )}

      <View style={styles.screenArea}>
        {tab === "caisse" && <CaisseScreen />}
        {tab === "encours" && <CommandeScreen />}
        {tab === "historique" && <HistoriqueScreen />}
        {tab === "rapports" && <RapportsScreen />}
        {tab === "stock" && <StockScreen />}
        {tab === "catalogue" && <CatalogueScreen />}
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabBar} contentContainerStyle={{ flexGrow: 1 }}>
        {TABS.map((t) => (
          <TouchableOpacity key={t.key} style={styles.tabBtn} onPress={() => setTab(t.key)}>
            <View>
              <Text style={styles.tabIcon}>{t.icon}</Text>
              {!!t.badge && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{t.badge}</Text>
                </View>
              )}
            </View>
            <Text style={[styles.tabLabel, tab === t.key && styles.tabLabelActive]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <AppProvider>
      <StatusBar barStyle="light-content" backgroundColor={colors.emerald} />
      <AppShell />
    </AppProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  header: { backgroundColor: colors.emerald, paddingVertical: 14, paddingHorizontal: 20, flexDirection: "row", alignItems: "baseline", gap: 8 },
  headerTitle: { color: colors.cream, fontWeight: "700", fontSize: 20, letterSpacing: -0.5 },
  headerSubtitle: { color: colors.cream, opacity: 0.75, fontSize: 12, marginLeft: 8 },
  trialBanner: { backgroundColor: "#FFF6E8", borderBottomWidth: 1, borderColor: colors.amber, paddingVertical: 7, paddingHorizontal: 14 },
  trialText: { fontSize: 11.5, color: "#8A5A00", textAlign: "center", fontWeight: "600" },
  lockedBanner: { backgroundColor: "#FDEBE6", borderBottomWidth: 1, borderColor: colors.rust, paddingVertical: 9, paddingHorizontal: 14 },
  lockedText: { fontSize: 11.5, color: "#8A2E10", textAlign: "center" },
  toast: { position: "absolute", top: 90, left: 20, right: 20, backgroundColor: colors.charcoal, borderRadius: 8, padding: 10, zIndex: 50 },
  toastText: { color: colors.cream, fontSize: 12.5, textAlign: "center" },
  screenArea: { flex: 1 },
  tabBar: { flexGrow: 0, borderTopWidth: 1, borderColor: colors.sage, backgroundColor: colors.white, paddingBottom: 6, paddingTop: 6 },
  tabBtn: { alignItems: "center", paddingVertical: 6, paddingHorizontal: 16, minWidth: 74 },
  tabIcon: { fontSize: 18, textAlign: "center" },
  tabLabel: { fontSize: 10.5, color: "#999", marginTop: 2 },
  tabLabelActive: { color: colors.emerald, fontWeight: "700" },
  badge: { position: "absolute", top: -4, right: -8, backgroundColor: colors.rust, borderRadius: 999, minWidth: 15, height: 15, alignItems: "center", justifyContent: "center", paddingHorizontal: 3 },
  badgeText: { color: colors.white, fontSize: 9, fontWeight: "700" },
});
