import AsyncStorage from "@react-native-async-storage/async-storage";

export async function loadJSON(key, fallback) {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.warn("storage load error", key, e);
    return fallback;
  }
}

export async function saveJSON(key, value) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn("storage save error", key, e);
  }
}

export const KEYS = {
  PRODUCTS: "tiket:products",
  SALES: "tiket:sales",
  PRINTER: "tiket:printer",
  OPEN_ORDERS: "tiket:openOrders",
  ORDER_SEQ: "tiket:orderSeq",
  STOCK_MOVEMENTS: "tiket:stockMovements",
  SUPPLIERS: "tiket:suppliers",
  TRIAL_START: "tiket:trialStart",
};
