// Service d'impression Bluetooth pour imprimantes thermiques ESC/POS classiques (SPP).
// Basé sur la librairie react-native-bluetooth-escpos-printer.
// Doc du package : https://github.com/januslo/react-native-bluetooth-escpos-printer
//
// IMPORTANT : cette librairie utilise des modules natifs Android/iOS.
// Elle ne fonctionne PAS dans Expo Go — il faut un projet React Native "bare"
// (ou Expo + expo-dev-client + prebuild). Voir le README à la racine du projet.

import { BluetoothManager, BluetoothEscposPrinter } from "react-native-bluetooth-escpos-printer";
import { Platform, PermissionsAndroid } from "react-native";

// Demande les permissions Bluetooth nécessaires sur Android 12+ (API 31+)
export async function requestBluetoothPermissions() {
  if (Platform.OS !== "android") return true;
  try {
    const granted = await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
    ]);
    return Object.values(granted).every((v) => v === PermissionsAndroid.RESULTS.GRANTED);
  } catch (e) {
    console.warn("Permission Bluetooth refusée ou indisponible", e);
    return false;
  }
}

// Vérifie et active le Bluetooth si besoin, puis liste les appareils
// déjà appairés + ceux détectés à proximité.
export async function scanForPrinters() {
  await requestBluetoothPermissions();

  const enabled = await BluetoothManager.isBluetoothEnabled();
  if (!enabled) {
    await BluetoothManager.enableBluetooth();
  }

  const raw = await BluetoothManager.scanDevices();
  // scanDevices() renvoie une chaîne JSON du type { found: [...], paired: [...] }
  let parsed = { found: [], paired: [] };
  try {
    parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch (e) {
    console.warn("Impossible de lire la liste des appareils Bluetooth", e);
  }

  const normalize = (list) =>
    (list || []).map((d) => ({
      name: d.name || "Appareil sans nom",
      address: d.address,
    }));

  return {
    paired: normalize(parsed.paired),
    found: normalize(parsed.found),
  };
}

// Se connecte à une imprimante par son adresse MAC Bluetooth
export async function connectPrinter(address) {
  await BluetoothManager.connect(address);
}

export async function disconnectPrinter() {
  try {
    await BluetoothManager.disconnect();
  } catch (e) {
    // pas grave si déjà déconnecté
  }
}

const LINE_WIDTH = 48; // caractères par ligne pour une imprimante 80mm (utiliser 32 pour 58mm)

function padLine(left, right, width = LINE_WIDTH) {
  const space = Math.max(1, width - left.length - right.length);
  return left + " ".repeat(space) + right;
}

// Imprime un reçu de paiement ou un ticket de commande sur l'imprimante connectée.
// `kind` = "recu" | "commande"
export async function printReceipt(sale, kind) {
  const items = kind === "commande" ? sale.items.filter((i) => i.needsCommande) : sale.items;

  await BluetoothEscposPrinter.printerInit();
  await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.CENTER);
  await BluetoothEscposPrinter.printText("TIKET\n", { fonttype: 1, widthtimes: 1, heigthtimes: 1 });
  await BluetoothEscposPrinter.printText(
    (kind === "commande" ? "TICKET DE COMMANDE" : "RECU DE PAIEMENT") + "\n",
    {}
  );
  await BluetoothEscposPrinter.printText("------------------------------------------------\n", {});
  await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.LEFT);
  await BluetoothEscposPrinter.printText(sale.date + "\n", {});
  if (sale.number) {
    await BluetoothEscposPrinter.printText(`Commande #${String(sale.number).padStart(4, "0")}\n`, {
      fonttype: 1,
    });
  }
  await BluetoothEscposPrinter.printText("------------------------------------------------\n", {});

  for (const item of items) {
    const label = `${item.qty}x ${item.name}`;
    if (kind === "commande") {
      await BluetoothEscposPrinter.printText(label + "\n", {});
    } else {
      const priceStr = fcfaCompact(item.price * item.qty);
      await BluetoothEscposPrinter.printText(padLine(label, priceStr) + "\n", {});
    }
  }

  if (kind !== "commande") {
    await BluetoothEscposPrinter.printText("------------------------------------------------\n", {});
    await BluetoothEscposPrinter.printText(padLine("TOTAL", fcfaCompact(sale.total)) + "\n", {
      fonttype: 1,
    });
    await BluetoothEscposPrinter.printText(`Paiement : ${sale.payMode}\n`, {});
  }

  await BluetoothEscposPrinter.printText("------------------------------------------------\n", {});
  await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.CENTER);
  await BluetoothEscposPrinter.printText(
    (kind === "commande" ? "-- a preparer --" : "Merci de votre visite !") + "\n\n\n",
    {}
  );
}

function fcfaCompact(n) {
  return n.toLocaleString("fr-FR") + "F";
}
