export const CATS = {
  resto: { label: "Restaurant", needsCommande: true },
  boutique: { label: "Boutique", needsCommande: false },
};

export const SEED_PRODUCTS = [
  { id: "p1", name: "Riz sauce graine", price: 1500, cat: "resto" },
  { id: "p2", name: "Poulet braisé", price: 2500, cat: "resto" },
  { id: "p3", name: "Attiéké poisson", price: 2000, cat: "resto" },
  { id: "p4", name: "Jus de bissap", price: 500, cat: "resto" },
  { id: "p5", name: "Bière 33cl", price: 1000, cat: "resto" },
  { id: "p6", name: "Savon liquide 1L", price: 1800, cat: "boutique", stock: 12, lowStock: 4 },
  { id: "p7", name: "Recharge crédit 1000F", price: 1000, cat: "boutique", stock: 40, lowStock: 10 },
  { id: "p8", name: "Sachet riz 5kg", price: 4500, cat: "boutique", stock: 8, lowStock: 3 },
  { id: "p9", name: "Huile 1L", price: 1600, cat: "boutique", stock: 15, lowStock: 5 },
];

export const PAY_MODES = ["Espèces", "Mobile Money", "Carte"];
export const TRIAL_DAYS = 7;
