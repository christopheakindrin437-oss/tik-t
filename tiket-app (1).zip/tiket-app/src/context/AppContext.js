import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { loadJSON, saveJSON, KEYS } from "../services/storage";
import { SEED_PRODUCTS, CATS, TRIAL_DAYS } from "../data/seedProducts";

const AppContext = createContext(null);

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function todayStr() {
  const d = new Date();
  return (
    d.toLocaleDateString("fr-FR") +
    " " +
    d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })
  );
}

export function AppProvider({ children }) {
  const [products, setProducts] = useState(SEED_PRODUCTS);
  const [sales, setSales] = useState([]);
  const [openOrders, setOpenOrders] = useState([]);
  const [orderSeq, setOrderSeq] = useState(1);
  const [cart, setCart] = useState([]);
  const [connectedPrinter, setConnectedPrinter] = useState(null); // { name, address }
  const [loaded, setLoaded] = useState(false);

  // Mode Boutique : stock, mouvements, fournisseurs
  const [stockMovements, setStockMovements] = useState([]);
  const [suppliers, setSuppliers] = useState([]);

  // Essai gratuit / abonnement
  const [trialStart, setTrialStart] = useState(null);
  const [demoLockPreview, setDemoLockPreview] = useState(false);
  const [lockMessage, setLockMessage] = useState(null);

  const flashLockMessage = useCallback((msg = "Essai gratuit terminé — abonnez-vous pour continuer") => {
    setLockMessage(msg);
    setTimeout(() => setLockMessage(null), 2500);
  }, []);

  useEffect(() => {
    (async () => {
      setProducts(await loadJSON(KEYS.PRODUCTS, SEED_PRODUCTS));
      setSales(await loadJSON(KEYS.SALES, []));
      setOpenOrders(await loadJSON(KEYS.OPEN_ORDERS, []));
      setOrderSeq(await loadJSON(KEYS.ORDER_SEQ, 1));
      setConnectedPrinter(await loadJSON(KEYS.PRINTER, null));
      setStockMovements(await loadJSON(KEYS.STOCK_MOVEMENTS, []));
      setSuppliers(await loadJSON(KEYS.SUPPLIERS, []));

      const ts = await loadJSON(KEYS.TRIAL_START, null);
      if (ts) {
        setTrialStart(ts);
      } else {
        const now = new Date().toISOString();
        setTrialStart(now);
        saveJSON(KEYS.TRIAL_START, now);
      }
      setLoaded(true);
    })();
  }, []);

  useEffect(() => { if (loaded) saveJSON(KEYS.PRODUCTS, products); }, [products, loaded]);
  useEffect(() => { if (loaded) saveJSON(KEYS.SALES, sales); }, [sales, loaded]);
  useEffect(() => { if (loaded) saveJSON(KEYS.OPEN_ORDERS, openOrders); }, [openOrders, loaded]);
  useEffect(() => { if (loaded) saveJSON(KEYS.ORDER_SEQ, orderSeq); }, [orderSeq, loaded]);
  useEffect(() => { if (loaded) saveJSON(KEYS.PRINTER, connectedPrinter); }, [connectedPrinter, loaded]);
  useEffect(() => { if (loaded) saveJSON(KEYS.STOCK_MOVEMENTS, stockMovements); }, [stockMovements, loaded]);
  useEffect(() => { if (loaded) saveJSON(KEYS.SUPPLIERS, suppliers); }, [suppliers, loaded]);

  // --- Essai gratuit ---
  const daysElapsed = trialStart
    ? Math.floor((Date.now() - new Date(trialStart).getTime()) / 86400000)
    : 0;
  const daysRemaining = Math.max(0, TRIAL_DAYS - daysElapsed);
  const isLocked = demoLockPreview || daysRemaining <= 0;

  const addToCart = useCallback(
    (prod) => {
      if (isLocked) {
        flashLockMessage();
        return false;
      }
      if (prod.cat === "boutique" && prod.stock !== undefined) {
        const inCart = cart.find((i) => i.id === prod.id)?.qty || 0;
        if (inCart + 1 > prod.stock) {
          flashLockMessage(`Stock insuffisant — ${prod.stock} restant(s)`);
          return "stock";
        }
      }
      setCart((c) => {
        const found = c.find((i) => i.id === prod.id);
        if (found) return c.map((i) => (i.id === prod.id ? { ...i, qty: i.qty + 1 } : i));
        return [...c, { ...prod, qty: 1, needsCommande: CATS[prod.cat]?.needsCommande }];
      });
      return true;
    },
    [cart, isLocked, flashLockMessage]
  );

  const changeQty = useCallback((id, delta) => {
    setCart((c) =>
      c.map((i) => (i.id === id ? { ...i, qty: i.qty + delta } : i)).filter((i) => i.qty > 0)
    );
  }, []);

  const removeFromCart = useCallback((id) => {
    setCart((c) => c.filter((i) => i.id !== id));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const hasCommandeItems = cart.some((i) => i.needsCommande);

  // Étape 1 : envoi de la commande (rien n'est encaissé)
  const sendOrder = useCallback(() => {
    if (isLocked) {
      flashLockMessage();
      return null;
    }
    if (cart.length === 0) return null;
    const order = {
      id: uid(),
      number: orderSeq,
      date: todayStr(),
      items: cart,
      hasCommande: cart.some((i) => i.needsCommande),
    };
    setOpenOrders((o) => [...o, order]);
    setOrderSeq((n) => n + 1);
    setCart([]);
    return order;
  }, [cart, orderSeq, isLocked, flashLockMessage]);

  // Étape 2 : validation du paiement + sortie de stock automatique
  const validatePayment = useCallback(
    (order, payMode) => {
      if (isLocked) {
        flashLockMessage();
        return null;
      }
      const total = order.items.reduce((s, i) => s + i.price * i.qty, 0);
      const sale = {
        id: uid(),
        number: order.number,
        date: todayStr(),
        items: order.items,
        total,
        payMode,
        hasCommande: order.hasCommande,
      };
      setSales((s) => [sale, ...s]);
      setOpenOrders((o) => o.filter((x) => x.id !== order.id));

      const boutiqueItems = order.items.filter((i) => i.cat === "boutique");
      if (boutiqueItems.length > 0) {
        setProducts((prev) =>
          prev.map((p) => {
            const sold = boutiqueItems.find((i) => i.id === p.id);
            if (!sold || p.stock === undefined) return p;
            return { ...p, stock: Math.max(0, p.stock - sold.qty) };
          })
        );
        setStockMovements((m) => [
          ...boutiqueItems
            .filter((i) => products.find((p) => p.id === i.id && p.stock !== undefined))
            .map((i) => ({
              id: uid(),
              date: todayStr(),
              productId: i.id,
              productName: i.name,
              type: "sortie",
              qty: i.qty,
              reason: `Vente — Commande #${String(order.number).padStart(4, "0")}`,
            })),
          ...m,
        ]);
      }
      return sale;
    },
    [isLocked, products, flashLockMessage]
  );

  const addProduct = useCallback(
    (prod) => {
      if (isLocked) {
        flashLockMessage();
        return;
      }
      setProducts((p) => [...p, { id: uid(), ...prod }]);
    },
    [isLocked, flashLockMessage]
  );

  const deleteProduct = useCallback(
    (id) => {
      if (isLocked) {
        flashLockMessage();
        return;
      }
      setProducts((p) => p.filter((x) => x.id !== id));
    },
    [isLocked, flashLockMessage]
  );

  const addStockEntry = useCallback(
    (productId, qty, supplierId) => {
      if (isLocked) {
        flashLockMessage();
        return;
      }
      if (!qty || qty <= 0) return;
      const product = products.find((p) => p.id === productId);
      if (!product) return;
      const supplier = suppliers.find((s) => s.id === supplierId);
      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, stock: (p.stock || 0) + qty } : p))
      );
      setStockMovements((m) => [
        {
          id: uid(),
          date: todayStr(),
          productId,
          productName: product.name,
          type: "entrée",
          qty,
          reason: supplier ? `Livraison — ${supplier.name}` : "Réapprovisionnement",
          supplierId: supplier?.id,
          supplierName: supplier?.name,
        },
        ...m,
      ]);
    },
    [isLocked, products, suppliers, flashLockMessage]
  );

  const addSupplier = useCallback(
    (supplier) => {
      if (isLocked) {
        flashLockMessage();
        return;
      }
      if (!supplier.name?.trim()) return;
      setSuppliers((s) => [...s, { id: uid(), ...supplier, name: supplier.name.trim() }]);
    },
    [isLocked, flashLockMessage]
  );

  const deleteSupplier = useCallback(
    (id) => {
      if (isLocked) {
        flashLockMessage();
        return;
      }
      setSuppliers((s) => s.filter((x) => x.id !== id));
    },
    [isLocked, flashLockMessage]
  );

  const value = {
    products,
    sales,
    openOrders,
    cart,
    total,
    hasCommandeItems,
    connectedPrinter,
    setConnectedPrinter,
    stockMovements,
    suppliers,
    daysRemaining,
    isLocked,
    demoLockPreview,
    setDemoLockPreview,
    lockMessage,
    addToCart,
    changeQty,
    removeFromCart,
    clearCart,
    sendOrder,
    validatePayment,
    addProduct,
    deleteProduct,
    addStockEntry,
    addSupplier,
    deleteSupplier,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp doit être utilisé à l'intérieur de <AppProvider>");
  return ctx;
}
