import React, { useState } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from "react-native";
import { useApp } from "../context/AppContext";
import { colors, fcfa } from "../theme";
import { printReceipt } from "../services/bluetoothPrinter";

export default function HistoriqueScreen() {
  const { sales, connectedPrinter, isLocked } = useApp();
  const [printing, setPrinting] = useState(false);

  const todayLabel = new Date().toLocaleDateString("fr-FR");
  const salesToday = sales.filter((s) => s.date.startsWith(todayLabel));
  const totalToday = salesToday.reduce((s, x) => s + x.total, 0);

  async function handlePrint(sale, kind) {
    if (isLocked) {
      Alert.alert("Essai gratuit terminé", "Abonne-toi pour réactiver l'impression.");
      return;
    }
    if (!connectedPrinter) {
      Alert.alert("Aucune imprimante connectée", "Connecte une imprimante depuis l'onglet Catalogue.");
      return;
    }
    setPrinting(true);
    try {
      await printReceipt(sale, kind);
    } catch (e) {
      Alert.alert("Erreur d'impression", String(e?.message || e));
    } finally {
      setPrinting(false);
    }
  }

  return (
    <View style={styles.root}>
      <View style={styles.statsRow}>
        <Stat label="Ventes aujourd'hui" value={String(salesToday.length)} />
        <Stat label="Encaissé aujourd'hui" value={fcfa(totalToday)} />
        <Stat label="Total ventes" value={String(sales.length)} />
      </View>

      <FlatList
        data={sales}
        keyExtractor={(s) => s.id}
        contentContainerStyle={{ padding: 16, paddingTop: 4 }}
        ListEmptyComponent={<Text style={styles.empty}>Aucune vente enregistrée.</Text>}
        renderItem={({ item: s }) => (
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTotal}>
                {fcfa(s.total)} {s.number ? `· #${String(s.number).padStart(4, "0")}` : ""}
              </Text>
              <Text style={styles.rowMeta}>
                {s.date} · {s.payMode} · {s.items.reduce((a, i) => a + i.qty, 0)} article(s)
              </Text>
            </View>
            <View style={styles.rowActions}>
              <TouchableOpacity
                style={styles.smallBtn}
                disabled={printing}
                onPress={() => handlePrint(s, "recu")}
              >
                <Text style={styles.smallBtnText}>Reçu</Text>
              </TouchableOpacity>
              {s.hasCommande && (
                <TouchableOpacity
                  style={styles.smallBtn}
                  disabled={printing}
                  onPress={() => handlePrint(s, "commande")}
                >
                  <Text style={styles.smallBtnText}>Commande</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}
      />
    </View>
  );
}

function Stat({ label, value }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  statsRow: { flexDirection: "row", gap: 10, padding: 16, paddingBottom: 4, flexWrap: "wrap" },
  stat: { flex: 1, minWidth: 100, backgroundColor: colors.white, borderRadius: 10, borderWidth: 1, borderColor: colors.sage, padding: 12, marginRight: 10, marginBottom: 10 },
  statLabel: { fontSize: 10.5, color: "#777", marginBottom: 4 },
  statValue: { fontSize: 17, fontWeight: "700", color: colors.charcoal },
  empty: { textAlign: "center", color: "#999", marginTop: 24 },
  row: {
    backgroundColor: colors.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.sage,
    padding: 12,
    marginBottom: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  rowTotal: { fontWeight: "700", fontSize: 14, color: colors.charcoal },
  rowMeta: { fontSize: 11.5, color: "#777", marginTop: 2 },
  rowActions: { flexDirection: "row", gap: 6 },
  smallBtn: { borderWidth: 1, borderColor: colors.sage, borderRadius: 6, paddingVertical: 6, paddingHorizontal: 10, marginLeft: 6, backgroundColor: colors.cream },
  smallBtnText: { fontSize: 11.5, color: colors.charcoal, fontWeight: "500" },
});
