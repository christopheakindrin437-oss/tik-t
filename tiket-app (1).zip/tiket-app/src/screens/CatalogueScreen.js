import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useApp } from "../context/AppContext";
import { colors, fcfa } from "../theme";
import { CATS } from "../data/seedProducts";
import { scanForPrinters, connectPrinter, disconnectPrinter } from "../services/bluetoothPrinter";

export default function CatalogueScreen() {
  const {
    products,
    addProduct,
    deleteProduct,
    connectedPrinter,
    setConnectedPrinter,
    daysRemaining,
    isLocked,
    demoLockPreview,
    setDemoLockPreview,
  } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [cat, setCat] = useState("boutique");
  const [stock, setStock] = useState("");
  const [lowStock, setLowStock] = useState("5");

  const [pickerOpen, setPickerOpen] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [devices, setDevices] = useState({ paired: [], found: [] });
  const [connecting, setConnecting] = useState(null);

  function handleAdd() {
    if (!name.trim() || !price) return;
    addProduct({
      name: name.trim(),
      price: Number(price),
      cat,
      ...(cat === "boutique"
        ? { stock: stock === "" ? 0 : Number(stock), lowStock: lowStock === "" ? 5 : Number(lowStock) }
        : {}),
    });
    setName("");
    setPrice("");
    setCat("boutique");
    setStock("");
    setLowStock("5");
    setShowForm(false);
  }

  async function openPicker() {
    setPickerOpen(true);
    setScanning(true);
    try {
      const result = await scanForPrinters();
      setDevices(result);
    } catch (e) {
      Alert.alert("Bluetooth indisponible", String(e?.message || e));
    } finally {
      setScanning(false);
    }
  }

  async function handleConnect(device) {
    setConnecting(device.address);
    try {
      await connectPrinter(device.address);
      setConnectedPrinter(device);
      setPickerOpen(false);
    } catch (e) {
      Alert.alert("Connexion impossible", String(e?.message || e));
    } finally {
      setConnecting(null);
    }
  }

  async function handleDisconnect() {
    await disconnectPrinter();
    setConnectedPrinter(null);
  }

  return (
    <View style={styles.root}>
      <View style={styles.printerCard}>
        <Text style={styles.sectionTitle}>Imprimante Bluetooth</Text>
        {connectedPrinter ? (
          <View style={styles.printerRow}>
            <Text style={styles.printerName}>🖨️ {connectedPrinter.name}</Text>
            <TouchableOpacity onPress={handleDisconnect}>
              <Text style={styles.disconnectText}>déconnecter</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity style={styles.connectBtn} onPress={openPicker}>
            <Text style={styles.connectBtnText}>Connecter une imprimante</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.headerRow}>
        <Text style={styles.sectionTitle}>Catalogue produits</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowForm((v) => !v)}>
          <Text style={styles.addBtnText}>{showForm ? "Annuler" : "+ Ajouter"}</Text>
        </TouchableOpacity>
      </View>

      {showForm && (
        <View style={styles.form}>
          <TextInput style={styles.input} placeholder="Nom du produit" value={name} onChangeText={setName} />
          <TextInput
            style={styles.input}
            placeholder="Prix (FCFA)"
            keyboardType="numeric"
            value={price}
            onChangeText={setPrice}
          />
          <View style={styles.catRow}>
            {["boutique", "resto"].map((k) => (
              <TouchableOpacity
                key={k}
                style={[styles.catChip, cat === k && styles.catChipActive]}
                onPress={() => setCat(k)}
              >
                <Text style={[styles.catChipText, cat === k && styles.catChipTextActive]}>
                  {CATS[k].label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          {cat === "boutique" && (
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 8 }}>
              <TextInput
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                placeholder="Stock initial"
                keyboardType="numeric"
                value={stock}
                onChangeText={setStock}
              />
              <TextInput
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                placeholder="Seuil alerte"
                keyboardType="numeric"
                value={lowStock}
                onChangeText={setLowStock}
              />
            </View>
          )}
          <TouchableOpacity style={styles.saveBtn} onPress={handleAdd}>
            <Text style={styles.saveBtnText}>Enregistrer</Text>
          </TouchableOpacity>
        </View>
      )}

      <FlatList
        data={products}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: 16, paddingTop: 8 }}
        renderItem={({ item: p }) => (
          <View style={styles.prodRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.prodName}>{p.name}</Text>
              <Text style={[styles.prodCat, { color: p.cat === "resto" ? colors.rust : colors.emerald }]}>
                {CATS[p.cat].label}
                {p.stock !== undefined ? ` · ${p.stock} en stock` : ""}
              </Text>
            </View>
            <Text style={styles.prodPrice}>{fcfa(p.price)}</Text>
            <TouchableOpacity onPress={() => deleteProduct(p.id)}>
              <Text style={styles.deleteText}>supprimer</Text>
            </TouchableOpacity>
          </View>
        )}
        ListFooterComponent={
          <View style={styles.subscriptionBox}>
            <Text style={styles.subscriptionTitle}>Abonnement</Text>
            <Text style={styles.subscriptionText}>
              {isLocked
                ? "Essai gratuit terminé. Abonne-toi pour retrouver l'accès complet."
                : `Essai gratuit en cours — ${daysRemaining} jour${daysRemaining > 1 ? "s" : ""} restant${daysRemaining > 1 ? "s" : ""}.`}
            </Text>
            <TouchableOpacity
              style={styles.previewToggle}
              onPress={() => setDemoLockPreview(!demoLockPreview)}
            >
              <Text style={styles.previewToggleText}>
                {demoLockPreview ? "☑" : "☐"} Aperçu du mode verrouillé (démo)
              </Text>
            </TouchableOpacity>
          </View>
        }
      />

      <Modal visible={pickerOpen} animationType="slide" onRequestClose={() => setPickerOpen(false)}>
        <View style={styles.modalRoot}>
          <Text style={styles.modalTitle}>Choisir une imprimante</Text>
          {scanning && (
            <View style={styles.scanningRow}>
              <ActivityIndicator />
              <Text style={styles.scanningText}>Recherche des appareils Bluetooth…</Text>
            </View>
          )}

          <Text style={styles.groupLabel}>Appareils appairés</Text>
          <FlatList
            data={devices.paired}
            keyExtractor={(d) => d.address}
            ListEmptyComponent={<Text style={styles.emptyList}>Aucun appareil appairé pour l'instant.</Text>}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.deviceRow} onPress={() => handleConnect(item)}>
                <Text style={styles.deviceName}>{item.name}</Text>
                {connecting === item.address ? <ActivityIndicator /> : <Text style={styles.deviceAction}>connecter</Text>}
              </TouchableOpacity>
            )}
          />

          <Text style={styles.groupLabel}>Appareils détectés à proximité</Text>
          <FlatList
            data={devices.found}
            keyExtractor={(d) => d.address}
            ListEmptyComponent={<Text style={styles.emptyList}>Aucun appareil trouvé.</Text>}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.deviceRow} onPress={() => handleConnect(item)}>
                <Text style={styles.deviceName}>{item.name}</Text>
                {connecting === item.address ? <ActivityIndicator /> : <Text style={styles.deviceAction}>connecter</Text>}
              </TouchableOpacity>
            )}
          />

          <TouchableOpacity style={styles.rescanBtn} onPress={openPicker}>
            <Text style={styles.rescanText}>🔄 Relancer la recherche</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.closeBtn} onPress={() => setPickerOpen(false)}>
            <Text style={styles.closeText}>Fermer</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  printerCard: { margin: 16, marginBottom: 4, backgroundColor: colors.white, borderRadius: 10, borderWidth: 1, borderColor: colors.sage, padding: 14 },
  sectionTitle: { fontSize: 15, fontWeight: "700", color: colors.charcoal, marginBottom: 8 },
  printerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  printerName: { fontSize: 13, color: colors.emerald, fontWeight: "600" },
  disconnectText: { fontSize: 12, color: colors.rust },
  connectBtn: { backgroundColor: colors.emerald, borderRadius: 8, paddingVertical: 10, alignItems: "center" },
  connectBtnText: { color: colors.white, fontWeight: "600", fontSize: 13 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 16, paddingBottom: 6 },
  addBtn: { backgroundColor: colors.emerald, borderRadius: 7, paddingVertical: 8, paddingHorizontal: 12 },
  addBtnText: { color: colors.white, fontSize: 12.5, fontWeight: "600" },
  form: { backgroundColor: colors.white, marginHorizontal: 16, borderRadius: 10, borderWidth: 1, borderColor: colors.sage, padding: 14, gap: 8 },
  input: { borderWidth: 1, borderColor: colors.sage, borderRadius: 7, paddingHorizontal: 12, paddingVertical: 9, fontSize: 13, marginBottom: 8 },
  catRow: { flexDirection: "row", gap: 8, marginBottom: 8 },
  catChip: { borderWidth: 1, borderColor: colors.sage, borderRadius: 7, paddingVertical: 7, paddingHorizontal: 12, marginRight: 8 },
  catChipActive: { backgroundColor: colors.emerald, borderColor: colors.emerald },
  catChipText: { fontSize: 12, color: colors.charcoal },
  catChipTextActive: { color: colors.white },
  saveBtn: { backgroundColor: colors.amber, borderRadius: 8, paddingVertical: 10, alignItems: "center" },
  saveBtnText: { fontWeight: "700", color: colors.charcoal, fontSize: 13 },
  prodRow: { flexDirection: "row", alignItems: "center", backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 12, marginBottom: 8, gap: 10 },
  prodName: { fontWeight: "600", fontSize: 13.5, color: colors.charcoal },
  prodCat: { fontSize: 11, marginTop: 2 },
  prodPrice: { fontSize: 13, fontFamily: "monospace" },
  deleteText: { fontSize: 12, color: colors.rust },
  subscriptionBox: { backgroundColor: colors.white, borderWidth: 1, borderStyle: "dashed", borderColor: colors.sage, borderRadius: 10, padding: 14, marginTop: 8 },
  subscriptionTitle: { fontSize: 11, fontWeight: "700", color: "#8A928F", textTransform: "uppercase", marginBottom: 8 },
  subscriptionText: { fontSize: 12.5, color: colors.charcoal, marginBottom: 10 },
  previewToggle: { paddingVertical: 4 },
  previewToggleText: { fontSize: 11.5, color: "#777" },
  modalRoot: { flex: 1, backgroundColor: colors.cream, padding: 20, paddingTop: 50 },
  modalTitle: { fontSize: 18, fontWeight: "700", marginBottom: 14, color: colors.charcoal },
  scanningRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  scanningText: { fontSize: 12, color: "#777", marginLeft: 8 },
  groupLabel: { fontSize: 11, fontWeight: "700", color: "#888", textTransform: "uppercase", marginTop: 12, marginBottom: 6 },
  emptyList: { fontSize: 12, color: "#999", marginBottom: 8 },
  deviceRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 8, padding: 12, marginBottom: 8 },
  deviceName: { fontSize: 13, color: colors.charcoal },
  deviceAction: { fontSize: 12, color: colors.emerald, fontWeight: "600" },
  rescanBtn: { marginTop: 16, alignItems: "center" },
  rescanText: { color: colors.emerald, fontSize: 13, fontWeight: "600" },
  closeBtn: { marginTop: 20, alignItems: "center", paddingVertical: 12 },
  closeText: { color: colors.rust, fontSize: 13, fontWeight: "600" },
});
