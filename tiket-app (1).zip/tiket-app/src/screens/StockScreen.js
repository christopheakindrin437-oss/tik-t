import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { useApp } from "../context/AppContext";
import { colors, fcfa } from "../theme";

const SUB_TABS = [
  { key: "inventaire", label: "Inventaire" },
  { key: "mouvements", label: "Mouvements" },
  { key: "fournisseurs", label: "Fournisseurs" },
];

export default function StockScreen() {
  const { products, stockMovements, suppliers, addStockEntry, addSupplier, deleteSupplier } = useApp();
  const [subTab, setSubTab] = useState("inventaire");
  const [entryId, setEntryId] = useState(null);
  const [entryQty, setEntryQty] = useState("");
  const [entrySupplierId, setEntrySupplierId] = useState("");
  const [newSupplier, setNewSupplier] = useState({ name: "", phone: "", note: "" });

  const boutiqueProducts = products.filter((p) => p.cat === "boutique");
  const lowStock = boutiqueProducts.filter((p) => p.stock !== undefined && p.stock <= (p.lowStock ?? 5));

  return (
    <View style={styles.root}>
      <Text style={styles.intro}>
        Le suivi de stock s'applique aux produits "Boutique". Les articles "Restaurant" sont préparés à la
        demande.
      </Text>

      <View style={styles.subTabRow}>
        {SUB_TABS.map((t) => (
          <TouchableOpacity
            key={t.key}
            style={[styles.subTabBtn, subTab === t.key && styles.subTabBtnActive]}
            onPress={() => setSubTab(t.key)}
          >
            <Text style={[styles.subTabText, subTab === t.key && styles.subTabTextActive]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {subTab === "inventaire" && (
        <FlatList
          data={boutiqueProducts}
          keyExtractor={(p) => p.id}
          contentContainerStyle={{ padding: 16, paddingTop: 8 }}
          ListHeaderComponent={
            lowStock.length > 0 ? (
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>⚠ {lowStock.length} produit(s) à surveiller</Text>
                <Text style={styles.alertList}>
                  {lowStock.map((p) => `${p.name} (${p.stock <= 0 ? "épuisé" : p.stock})`).join("  ·  ")}
                </Text>
              </View>
            ) : null
          }
          ListEmptyComponent={<Text style={styles.empty}>Aucun produit boutique dans le catalogue.</Text>}
          renderItem={({ item: p }) => {
            const isOut = (p.stock ?? 0) <= 0;
            const isLow = !isOut && p.stock <= (p.lowStock ?? 5);
            const isEntering = entryId === p.id;
            return (
              <View style={[styles.prodCard, isOut && styles.prodCardOut, isLow && styles.prodCardLow]}>
                <View style={styles.prodRow}>
                  <View>
                    <Text style={styles.prodName}>{p.name}</Text>
                    <Text style={styles.prodThreshold}>Seuil : {p.lowStock ?? 5}</Text>
                  </View>
                  <View style={styles.prodRight}>
                    <Text style={[styles.prodStock, isOut && styles.textRust, isLow && styles.textAmber]}>
                      {isOut ? "épuisé" : `${p.stock} en stock`}
                    </Text>
                    <TouchableOpacity
                      style={styles.entryBtn}
                      onPress={() => {
                        setEntryId(isEntering ? null : p.id);
                        setEntryQty("");
                        setEntrySupplierId("");
                      }}
                    >
                      <Text style={styles.entryBtnText}>+ Entrée</Text>
                    </TouchableOpacity>
                  </View>
                </View>
                {isEntering && (
                  <View style={styles.entryForm}>
                    <TextInput
                      placeholder="Quantité reçue"
                      keyboardType="numeric"
                      value={entryQty}
                      onChangeText={setEntryQty}
                      style={styles.input}
                    />
                    <TouchableOpacity
                      style={styles.validateEntryBtn}
                      onPress={() => {
                        addStockEntry(p.id, Number(entryQty), entrySupplierId);
                        setEntryId(null);
                      }}
                    >
                      <Text style={styles.validateEntryText}>Valider l'entrée</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            );
          }}
        />
      )}

      {subTab === "mouvements" && (
        <FlatList
          data={stockMovements}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ padding: 16, paddingTop: 8 }}
          ListEmptyComponent={<Text style={styles.empty}>Aucun mouvement de stock enregistré.</Text>}
          renderItem={({ item: m }) => (
            <View style={styles.moveRow}>
              <View>
                <Text style={styles.moveProduct}>{m.productName}</Text>
                <Text style={styles.moveReason}>{m.date} · {m.reason}</Text>
              </View>
              <Text style={[styles.moveQty, m.type === "entrée" ? styles.textEmerald : styles.textRust]}>
                {m.type === "entrée" ? "+" : "−"}{m.qty}
              </Text>
            </View>
          )}
        />
      )}

      {subTab === "fournisseurs" && (
        <FlatList
          data={suppliers}
          keyExtractor={(s) => s.id}
          contentContainerStyle={{ padding: 16, paddingTop: 8 }}
          ListHeaderComponent={
            <View style={styles.supplierForm}>
              <TextInput
                placeholder="Nom du fournisseur"
                value={newSupplier.name}
                onChangeText={(t) => setNewSupplier((s) => ({ ...s, name: t }))}
                style={styles.input}
              />
              <TextInput
                placeholder="Téléphone"
                value={newSupplier.phone}
                onChangeText={(t) => setNewSupplier((s) => ({ ...s, phone: t }))}
                style={styles.input}
              />
              <TouchableOpacity
                style={styles.addSupplierBtn}
                onPress={() => {
                  addSupplier(newSupplier);
                  setNewSupplier({ name: "", phone: "", note: "" });
                }}
              >
                <Text style={styles.addSupplierText}>Ajouter le fournisseur</Text>
              </TouchableOpacity>
            </View>
          }
          ListEmptyComponent={<Text style={styles.empty}>Aucun fournisseur enregistré.</Text>}
          renderItem={({ item: s }) => (
            <View style={styles.supplierRow}>
              <View>
                <Text style={styles.supplierName}>{s.name}</Text>
                <Text style={styles.supplierPhone}>{s.phone}</Text>
              </View>
              <TouchableOpacity onPress={() => deleteSupplier(s.id)}>
                <Text style={styles.deleteText}>supprimer</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  intro: { fontSize: 11.5, color: "#777", paddingHorizontal: 16, paddingTop: 14 },
  subTabRow: { flexDirection: "row", gap: 8, paddingHorizontal: 16, paddingTop: 12 },
  subTabBtn: { paddingVertical: 7, paddingHorizontal: 12, borderRadius: 8, borderWidth: 1.5, borderColor: colors.sage, backgroundColor: colors.white },
  subTabBtnActive: { backgroundColor: colors.emerald, borderColor: colors.emerald },
  subTabText: { fontSize: 12.5, color: colors.charcoal, fontWeight: "500" },
  subTabTextActive: { color: colors.white },
  empty: { textAlign: "center", color: "#999", marginTop: 20 },
  alertBox: { backgroundColor: "#FFF6E8", borderWidth: 1, borderColor: colors.amber, borderRadius: 10, padding: 12, marginBottom: 12 },
  alertTitle: { fontSize: 11.5, fontWeight: "700", color: "#B57200", marginBottom: 4 },
  alertList: { fontSize: 11, color: "#B57200" },
  prodCard: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 12, marginBottom: 8 },
  prodCardOut: { borderColor: colors.rust },
  prodCardLow: { borderColor: colors.amber },
  prodRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  prodName: { fontSize: 13.5, fontWeight: "600", color: colors.charcoal },
  prodThreshold: { fontSize: 10.5, color: "#888", marginTop: 2 },
  prodRight: { alignItems: "flex-end", gap: 6 },
  prodStock: { fontSize: 12.5, fontWeight: "700", color: colors.emerald },
  textRust: { color: colors.rust },
  textAmber: { color: "#B57200" },
  textEmerald: { color: colors.emerald },
  entryBtn: { borderWidth: 1, borderColor: colors.sage, borderRadius: 6, paddingVertical: 5, paddingHorizontal: 10, backgroundColor: colors.cream },
  entryBtnText: { fontSize: 11, color: colors.charcoal, fontWeight: "500" },
  entryForm: { flexDirection: "row", gap: 8, marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderColor: colors.sage, borderStyle: "dashed" },
  input: { flex: 1, borderWidth: 1, borderColor: colors.sage, borderRadius: 7, paddingHorizontal: 10, paddingVertical: 8, fontSize: 12.5, marginBottom: 8 },
  validateEntryBtn: { backgroundColor: colors.emerald, borderRadius: 7, paddingVertical: 9, paddingHorizontal: 12, alignItems: "center", justifyContent: "center" },
  validateEntryText: { color: colors.white, fontSize: 11.5, fontWeight: "600" },
  moveRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 12, marginBottom: 8 },
  moveProduct: { fontSize: 13, fontWeight: "600", color: colors.charcoal },
  moveReason: { fontSize: 10.5, color: "#888", marginTop: 2 },
  moveQty: { fontSize: 14, fontWeight: "700" },
  supplierForm: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 14, marginBottom: 12 },
  addSupplierBtn: { backgroundColor: colors.amber, borderRadius: 8, paddingVertical: 10, alignItems: "center" },
  addSupplierText: { fontWeight: "700", fontSize: 13, color: colors.charcoal },
  supplierRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 12, marginBottom: 8 },
  supplierName: { fontSize: 13, fontWeight: "600", color: colors.charcoal },
  supplierPhone: { fontSize: 11, color: "#888", marginTop: 2 },
  deleteText: { fontSize: 12, color: colors.rust },
});
