import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useApp } from "../context/AppContext";
import { colors, fcfa } from "../theme";
import { CATS } from "../data/seedProducts";
import { printReceipt } from "../services/bluetoothPrinter";

export default function CaisseScreen() {
  const { products, cart, total, connectedPrinter, addToCart, changeQty, removeFromCart, sendOrder, isLocked } =
    useApp();

  const [catFilter, setCatFilter] = useState("all");
  const [lastOrder, setLastOrder] = useState(null);
  const [printing, setPrinting] = useState(false);

  const filtered = catFilter === "all" ? products : products.filter((p) => p.cat === catFilter);

  function handleSend() {
    if (cart.length === 0 || isLocked) return;
    const order = sendOrder();
    if (!order) return;
    setLastOrder(order);
    Alert.alert(
      "Commande envoyée",
      `Commande #${String(order.number).padStart(4, "0")} — ${fcfa(
        order.items.reduce((s, i) => s + i.price * i.qty, 0)
      )}\n\nRetrouve-la dans l'onglet "Commandes" pour l'encaisser une fois le client servi.`
    );
  }

  async function handlePrintKitchen() {
    if (!lastOrder) return;
    if (isLocked) {
      Alert.alert("Essai gratuit terminé", "Abonne-toi pour réactiver l'impression.");
      return;
    }
    if (!connectedPrinter) {
      Alert.alert("Aucune imprimante connectée", "Connecte une imprimante depuis l'onglet Catalogue.");
      return;
    }
    setPrinting(true);
    try {
      await printReceipt(lastOrder, "commande");
    } catch (e) {
      Alert.alert("Erreur d'impression", String(e?.message || e));
    } finally {
      setPrinting(false);
    }
  }

  return (
    <View style={styles.root}>
      <ScrollView style={styles.productArea} contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.filterLabel}>Catégorie</Text>
        <View style={styles.filters}>
          {[
            ["all", "Tout"],
            ["resto", "Restaurant"],
            ["boutique", "Boutique"],
          ].map(([k, label]) => (
            <TouchableOpacity
              key={k}
              onPress={() => setCatFilter(k)}
              style={[styles.filterBtn, catFilter === k && styles.filterBtnActive]}
            >
              <Text style={[styles.filterText, catFilter === k && styles.filterTextActive]}>
                {label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.grid}>
          {filtered.map((p) => (
            <TouchableOpacity key={p.id} style={styles.card} onPress={() => addToCart(p)}>
              <Text style={[styles.cardCat, { color: p.cat === "resto" ? colors.rust : colors.emerald }]}>
                {CATS[p.cat].label}
              </Text>
              <Text style={styles.cardName}>{p.name}</Text>
              <Text style={styles.cardPrice}>{fcfa(p.price)}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.ticket}>
        <ScrollView style={{ maxHeight: 220 }}>
          {cart.length === 0 && <Text style={styles.emptyCart}>Panier vide — touchez un produit</Text>}
          {cart.map((i) => (
            <View key={i.id} style={styles.cartRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.cartName}>{i.name}</Text>
                <View style={styles.qtyRow}>
                  <TouchableOpacity onPress={() => changeQty(i.id, -1)} style={styles.qtyBtn}>
                    <Text style={styles.qtyBtnText}>−</Text>
                  </TouchableOpacity>
                  <Text style={styles.qtyValue}>{i.qty}</Text>
                  <TouchableOpacity onPress={() => changeQty(i.id, 1)} style={styles.qtyBtn}>
                    <Text style={styles.qtyBtnText}>+</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => removeFromCart(i.id)}>
                    <Text style={styles.removeText}>retirer</Text>
                  </TouchableOpacity>
                </View>
              </View>
              <Text style={styles.cartPrice}>{fcfa(i.price * i.qty)}</Text>
            </View>
          ))}
        </ScrollView>

        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>TOTAL</Text>
          <Text style={styles.totalValue}>{fcfa(total)}</Text>
        </View>

        <TouchableOpacity
          style={[styles.confirmBtn, (cart.length === 0 || isLocked) && styles.confirmBtnDisabled]}
          disabled={cart.length === 0 || isLocked}
          onPress={handleSend}
        >
          <Text style={styles.confirmText}>
            {isLocked ? "Essai terminé — abonnement requis" : `Envoyer la commande ${cart.length > 0 ? `· ${fcfa(total)}` : ""}`}
          </Text>
        </TouchableOpacity>

        {lastOrder && (
          <View style={styles.lastOrderBox}>
            <Text style={styles.lastOrderTitle}>
              Commande #{String(lastOrder.number).padStart(4, "0")} envoyée
            </Text>
            {lastOrder.hasCommande ? (
              <TouchableOpacity style={styles.printBtn} onPress={handlePrintKitchen} disabled={printing}>
                <Text style={styles.printBtnText}>{printing ? "Impression…" : "🍽️ Imprimer ticket cuisine"}</Text>
              </TouchableOpacity>
            ) : (
              <Text style={styles.lastOrderHint}>
                Encaisse-la depuis l'onglet "Commandes" une fois le client prêt à payer.
              </Text>
            )}
          </View>
        )}
        {!connectedPrinter && (
          <Text style={styles.printerWarning}>Aucune imprimante Bluetooth connectée (voir Catalogue)</Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  productArea: { flex: 1 },
  filterLabel: { fontSize: 11, fontWeight: "700", textTransform: "uppercase", color: "#8A928F", marginBottom: 8 },
  filters: { flexDirection: "row", gap: 8, marginBottom: 14 },
  filterBtn: {
    paddingVertical: 7,
    paddingHorizontal: 14,
    borderRadius: 8,
    borderWidth: 1.5,
    borderColor: colors.sage,
    backgroundColor: colors.white,
    marginRight: 8,
  },
  filterBtnActive: { backgroundColor: colors.emerald, borderColor: colors.emerald },
  filterText: { fontSize: 13, color: colors.charcoal, fontWeight: "500" },
  filterTextActive: { color: colors.white },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  card: {
    width: "47%",
    backgroundColor: colors.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.sage,
    padding: 12,
    marginBottom: 10,
  },
  cardCat: { fontSize: 10, fontWeight: "700", textTransform: "uppercase", marginBottom: 6 },
  cardName: { fontSize: 14, fontWeight: "600", color: colors.charcoal, marginBottom: 6 },
  cardPrice: { fontSize: 13, color: colors.charcoal },
  ticket: {
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderColor: colors.sage,
    padding: 16,
    maxHeight: "50%",
  },
  emptyCart: { textAlign: "center", color: "#999", paddingVertical: 16 },
  cartRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 8 },
  cartName: { fontSize: 13, color: colors.charcoal },
  qtyRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
  qtyBtn: { width: 24, height: 24, borderRadius: 5, borderWidth: 1, borderColor: "#ddd", alignItems: "center", justifyContent: "center" },
  qtyBtnText: { fontSize: 14 },
  qtyValue: { fontSize: 13, marginHorizontal: 4 },
  removeText: { fontSize: 11, color: colors.rust, marginLeft: 6 },
  cartPrice: { fontSize: 13, color: colors.charcoal },
  totalRow: { flexDirection: "row", justifyContent: "space-between", borderTopWidth: 1, borderColor: colors.sage, paddingTop: 10, marginTop: 8 },
  totalLabel: { fontWeight: "700", fontSize: 15 },
  totalValue: { fontWeight: "700", fontSize: 15 },
  confirmBtn: { backgroundColor: colors.amber, borderRadius: 8, paddingVertical: 14, alignItems: "center", marginTop: 12 },
  confirmBtnDisabled: { backgroundColor: "#ddd" },
  confirmText: { fontWeight: "700", fontSize: 14, color: colors.charcoal },
  lastOrderBox: { marginTop: 12, backgroundColor: colors.cream, borderRadius: 8, borderWidth: 1, borderColor: colors.sage, padding: 12 },
  lastOrderTitle: { fontSize: 11.5, fontWeight: "700", color: colors.emerald, textTransform: "uppercase", marginBottom: 8 },
  lastOrderHint: { fontSize: 12, color: "#777" },
  printBtn: { borderWidth: 1, borderColor: colors.emerald, borderRadius: 7, paddingVertical: 10, alignItems: "center" },
  printBtnText: { color: colors.emerald, fontWeight: "600", fontSize: 12.5 },
  printerWarning: { fontSize: 11, color: colors.rust, textAlign: "center", marginTop: 8 },
});
