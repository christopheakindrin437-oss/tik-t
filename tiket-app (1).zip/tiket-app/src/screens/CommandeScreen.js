import React, { useState } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, ActivityIndicator } from "react-native";
import { useApp } from "../context/AppContext";
import { colors, fcfa } from "../theme";
import { PAY_MODES } from "../data/seedProducts";
import { printReceipt } from "../services/bluetoothPrinter";

export default function CommandeScreen() {
  const { openOrders, connectedPrinter, validatePayment, isLocked } = useApp();
  const [payingId, setPayingId] = useState(null);
  const [payMode, setPayMode] = useState(PAY_MODES[0]);
  const [printing, setPrinting] = useState(false);
  const [justPaid, setJustPaid] = useState(null);

  async function handlePrint(target, kind) {
    if (isLocked) {
      Alert.alert("Essai gratuit terminé", "Abonne-toi pour réactiver l'impression.");
      return;
    }
    if (!connectedPrinter) {
      Alert.alert("Aucune imprimante connectée", "Connecte une imprimante depuis l'onglet Catalogue.");
      return;
    }
    setPrinting(true);
    try {
      await printReceipt(target, kind);
    } catch (e) {
      Alert.alert("Erreur d'impression", String(e?.message || e));
    } finally {
      setPrinting(false);
    }
  }

  function handleValidate(order) {
    const sale = validatePayment(order, payMode);
    if (!sale) return;
    setPayingId(null);
    setJustPaid(sale);
    Alert.alert(
      "Paiement validé",
      `Commande #${String(sale.number).padStart(4, "0")} encaissée — reçu prêt à imprimer`
    );
  }

  return (
    <View style={styles.root}>
      {justPaid && (
        <View style={styles.paidBox}>
          <Text style={styles.paidTitle}>
            Commande #{String(justPaid.number).padStart(4, "0")} encaissée — reçu prêt
          </Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <TouchableOpacity style={styles.printBtn} onPress={() => handlePrint(justPaid, "recu")} disabled={printing}>
              {printing ? <ActivityIndicator /> : <Text style={styles.printBtnText}>🧾 Imprimer le reçu</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={styles.closeBtn} onPress={() => setJustPaid(null)}>
              <Text style={styles.closeBtnText}>Fermer</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <FlatList
        data={openOrders}
        keyExtractor={(o) => o.id}
        contentContainerStyle={{ padding: 16, paddingTop: justPaid ? 4 : 16 }}
        ListEmptyComponent={<Text style={styles.empty}>Aucune commande en cours pour le moment.</Text>}
        renderItem={({ item: o }) => {
          const orderTotal = o.items.reduce((s, i) => s + i.price * i.qty, 0);
          const isPaying = payingId === o.id;
          return (
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View>
                  <Text style={styles.cardNumber}>Commande #{String(o.number).padStart(4, "0")}</Text>
                  <Text style={styles.cardDate}>{o.date}</Text>
                </View>
                <Text style={styles.cardTotal}>{fcfa(orderTotal)}</Text>
              </View>

              <View style={styles.itemsList}>
                {o.items.map((i, idx) => (
                  <View key={idx} style={styles.itemRow}>
                    <Text style={styles.itemText}>{i.qty}x {i.name}</Text>
                    <Text style={styles.itemPrice}>{fcfa(i.price * i.qty)}</Text>
                  </View>
                ))}
              </View>

              <View style={styles.actionsRow}>
                {o.hasCommande && (
                  <TouchableOpacity style={styles.smallBtn} onPress={() => handlePrint(o, "commande")} disabled={printing}>
                    <Text style={styles.smallBtnText}>🍽️ Ticket cuisine</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  style={styles.payBtn}
                  onPress={() => {
                    setPayingId(isPaying ? null : o.id);
                    setPayMode(PAY_MODES[0]);
                  }}
                >
                  <Text style={styles.payBtnText}>💰 Encaisser</Text>
                </TouchableOpacity>
              </View>

              {isPaying && (
                <View style={styles.payPanel}>
                  <View style={styles.payModeRow}>
                    {PAY_MODES.map((m) => (
                      <TouchableOpacity
                        key={m}
                        onPress={() => setPayMode(m)}
                        style={[styles.payModeBtn, payMode === m && styles.payModeBtnActive]}
                      >
                        <Text style={[styles.payModeText, payMode === m && styles.payModeTextActive]}>{m}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                  <TouchableOpacity style={styles.validateBtn} onPress={() => handleValidate(o)}>
                    <Text style={styles.validateText}>Valider le paiement · {fcfa(orderTotal)}</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  paidBox: { margin: 16, marginBottom: 4, backgroundColor: "#EAF6EE", borderWidth: 1, borderColor: colors.emerald, borderRadius: 10, padding: 14 },
  paidTitle: { fontSize: 11.5, fontWeight: "700", color: colors.emerald, textTransform: "uppercase", marginBottom: 10 },
  printBtn: { flex: 1, borderWidth: 1, borderColor: colors.emerald, borderRadius: 7, paddingVertical: 9, alignItems: "center" },
  printBtnText: { color: colors.emerald, fontWeight: "600", fontSize: 12 },
  closeBtn: { paddingVertical: 9, paddingHorizontal: 12, alignItems: "center" },
  closeBtnText: { color: colors.rust, fontWeight: "600", fontSize: 12 },
  empty: { textAlign: "center", color: "#999", marginTop: 24 },
  card: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 14, marginBottom: 12 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 },
  cardNumber: { fontWeight: "700", fontSize: 14.5, color: colors.charcoal },
  cardDate: { fontSize: 11, color: "#888", marginTop: 2 },
  cardTotal: { fontWeight: "700", fontSize: 14.5, color: colors.charcoal },
  itemsList: { marginBottom: 10 },
  itemRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 2 },
  itemText: { fontSize: 12.5, color: colors.charcoal },
  itemPrice: { fontSize: 12.5, color: "#777" },
  actionsRow: { flexDirection: "row", gap: 8 },
  smallBtn: { borderWidth: 1, borderColor: colors.sage, borderRadius: 6, paddingVertical: 8, paddingHorizontal: 10, backgroundColor: colors.cream },
  smallBtnText: { fontSize: 11.5, color: colors.charcoal, fontWeight: "500" },
  payBtn: { backgroundColor: colors.emerald, borderRadius: 6, paddingVertical: 8, paddingHorizontal: 12 },
  payBtnText: { fontSize: 11.5, color: colors.white, fontWeight: "600" },
  payPanel: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderColor: colors.sage, borderStyle: "dashed" },
  payModeRow: { flexDirection: "row", gap: 6, marginBottom: 10 },
  payModeBtn: { flex: 1, borderWidth: 1, borderColor: "#ddd", borderRadius: 6, paddingVertical: 8, alignItems: "center" },
  payModeBtnActive: { backgroundColor: colors.emerald, borderColor: colors.emerald },
  payModeText: { fontSize: 11, color: colors.charcoal, fontWeight: "500" },
  payModeTextActive: { color: colors.white },
  validateBtn: { backgroundColor: colors.amber, borderRadius: 8, paddingVertical: 12, alignItems: "center" },
  validateText: { fontWeight: "700", fontSize: 13, color: colors.charcoal },
});
