import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Share } from "react-native";
import { useApp } from "../context/AppContext";
import { colors, fcfa } from "../theme";

function parseFrDate(str) {
  const [datePart] = str.split(" ");
  const [dd, mm, yyyy] = datePart.split("/").map(Number);
  return new Date(yyyy, mm - 1, dd);
}
function dateKey(str) {
  return str.split(" ")[0];
}
function monthKey(str) {
  const d = parseFrDate(str);
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}
function shareCSV(rows, headers, title) {
  const csv = [headers.join(";"), ...rows.map((r) => r.join(";"))].join("\n");
  Share.share({ title, message: csv });
}

export default function RapportsScreen() {
  const { sales } = useApp();

  const dailyReport = Array.from({ length: 30 }).map((_, idx) => {
    const d = new Date();
    d.setDate(d.getDate() - (29 - idx));
    const key = d.toLocaleDateString("fr-FR");
    const daySales = sales.filter((s) => dateKey(s.date) === key);
    const revenue = daySales.reduce((sum, s) => sum + s.total, 0);
    return { key, label: d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }), count: daySales.length, revenue };
  });
  const dailyTotal = dailyReport.reduce((s, d) => s + d.revenue, 0);
  const dailyCount = dailyReport.reduce((s, d) => s + d.count, 0);
  const dailyAvg = dailyCount > 0 ? dailyTotal / dailyCount : 0;
  const maxDaily = Math.max(1, ...dailyReport.map((d) => d.revenue));

  const monthlyReport = Array.from({ length: 12 }).map((_, idx) => {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - (11 - idx));
    const key = `${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
    const monthSales = sales.filter((s) => monthKey(s.date) === key);
    const revenue = monthSales.reduce((sum, s) => sum + s.total, 0);
    return { key, label: d.toLocaleDateString("fr-FR", { month: "short", year: "numeric" }), count: monthSales.length, revenue };
  });
  const monthlyTotal = monthlyReport.reduce((s, m) => s + m.revenue, 0);
  const monthlyCount = monthlyReport.reduce((s, m) => s + m.count, 0);
  const monthlyAvg = monthlyCount > 0 ? monthlyTotal / monthlyCount : 0;
  const maxMonthly = Math.max(1, ...monthlyReport.map((m) => m.revenue));

  return (
    <ScrollView style={styles.root} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>30 derniers jours</Text>
        <TouchableOpacity
          style={styles.exportBtn}
          onPress={() =>
            shareCSV(
              dailyReport.map((d) => [d.key, d.count, d.revenue]),
              ["Date", "Ventes", "Chiffre d'affaires"],
              "Rapport journalier Tikèt"
            )
          }
        >
          <Text style={styles.exportBtnText}>⬇ Exporter</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.statsRow}>
        <Stat label="Total" value={fcfa(dailyTotal)} />
        <Stat label="Ventes" value={String(dailyCount)} />
        <Stat label="Moyenne" value={fcfa(Math.round(dailyAvg))} />
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chartScroll}>
        <View style={styles.barChart}>
          {dailyReport.map((d) => (
            <View key={d.key} style={styles.barCol}>
              <View style={[styles.bar, { height: Math.max(3, (d.revenue / maxDaily) * 70) }]} />
            </View>
          ))}
        </View>
      </ScrollView>

      <View style={[styles.sectionHeader, { marginTop: 24 }]}>
        <Text style={styles.sectionTitle}>12 derniers mois</Text>
        <TouchableOpacity
          style={styles.exportBtn}
          onPress={() =>
            shareCSV(
              monthlyReport.map((m) => [m.key, m.count, m.revenue]),
              ["Mois", "Ventes", "Chiffre d'affaires"],
              "Rapport mensuel Tikèt"
            )
          }
        >
          <Text style={styles.exportBtnText}>⬇ Exporter</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.statsRow}>
        <Stat label="Total" value={fcfa(monthlyTotal)} />
        <Stat label="Ventes" value={String(monthlyCount)} />
        <Stat label="Moyenne" value={fcfa(Math.round(monthlyAvg))} />
      </View>
      {monthlyReport.map((m) => (
        <View key={m.key} style={styles.monthRow}>
          <Text style={styles.monthLabel}>{m.label}</Text>
          <View style={styles.monthBarTrack}>
            <View style={[styles.monthBar, { width: `${Math.max(2, (m.revenue / maxMonthly) * 100)}%` }]} />
          </View>
          <Text style={styles.monthValue}>{fcfa(m.revenue)}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

function Stat({ label, value }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.cream },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  sectionTitle: { fontSize: 15, fontWeight: "700", color: colors.charcoal },
  exportBtn: { borderWidth: 1, borderColor: colors.sage, borderRadius: 6, paddingVertical: 6, paddingHorizontal: 10, backgroundColor: colors.white },
  exportBtnText: { fontSize: 11.5, color: colors.charcoal, fontWeight: "600" },
  statsRow: { flexDirection: "row", gap: 8, marginBottom: 12, flexWrap: "wrap" },
  stat: { flex: 1, minWidth: 100, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 10 },
  statLabel: { fontSize: 10, color: "#777" },
  statValue: { fontSize: 15, fontWeight: "700", color: colors.charcoal, marginTop: 2 },
  chartScroll: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.sage, borderRadius: 10, padding: 10 },
  barChart: { flexDirection: "row", alignItems: "flex-end", height: 80, gap: 3 },
  barCol: { width: 10, alignItems: "center", justifyContent: "flex-end", height: "100%" },
  bar: { width: "100%", backgroundColor: colors.emerald, borderRadius: 2 },
  monthRow: { flexDirection: "row", alignItems: "center", marginBottom: 8, gap: 8 },
  monthLabel: { width: 66, fontSize: 11, color: "#777", textTransform: "capitalize" },
  monthBarTrack: { flex: 1, height: 12, backgroundColor: colors.sage, borderRadius: 4, overflow: "hidden" },
  monthBar: { height: "100%", backgroundColor: colors.amber },
  monthValue: { width: 90, fontSize: 11, textAlign: "right", color: colors.charcoal },
});
