export const colors = {
  charcoal: "#1C2321",
  emerald: "#0F5257",
  emeraldDark: "#0A3A3D",
  amber: "#F2A104",
  cream: "#FAF7F2",
  sage: "#E4EAE8",
  rust: "#C1440E",
  white: "#FFFFFF",
};

export function fcfa(n) {
  return n.toLocaleString("fr-FR") + " FCFA";
}
